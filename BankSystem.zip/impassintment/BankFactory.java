package impassintment;

public abstract class BankFactory {
	public abstract SavingAcc getNewSavingAcc(int accNo, String accNm, float accBal, boolean issalaried);

	public abstract CurrentAcc getNewCurrentAcc(int accNo, String accNm, float accBal, float creditLimit);
}
