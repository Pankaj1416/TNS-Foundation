package impassintment;

public class app {

	public static void main(String[] args) {
      BankFactory bankfactory = new MMBankFactory();
      SavingAcc savingacc = bankfactory.getNewSavingAcc(1234,"pankaj",5000,true);
      
      CurrentAcc currentacc = bankfactory.getNewCurrentAcc(1234,"ram",3000,100);
      
      savingacc.withdraw(200);
      currentacc.withdraw(300);
      
      System.out.println(currentacc.toString());
      System.out.println(savingacc. toString());

      
	}

}
