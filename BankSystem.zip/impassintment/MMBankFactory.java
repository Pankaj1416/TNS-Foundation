package impassintment;

public class MMBankFactory extends BankFactory{

	@Override
	public SavingAcc getNewSavingAcc(int accNo, String accNm, float accBal, boolean issalaried) {
		return new MMSavingAcc(accNo,accNm,accBal,issalaried);
	}

	@Override
	public CurrentAcc getNewCurrentAcc(int accNo, String accNm, float accBal,float creditLimit) {
		return new MMCurrentAcc(accNo,accNm,accBal,creditLimit);
	}
	

}
