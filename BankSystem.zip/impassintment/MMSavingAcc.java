package impassintment;

public class MMSavingAcc extends SavingAcc {
	private static  float MINBAL;
	
	public MMSavingAcc(int accNo, String accNm, float accBal, boolean issalaried) {
		super(accNo,accNm,accBal,issalaried);	
	}
    @Override
	public void withdraw(float amount) {
		
	}
	@Override
	public String toString() {
		return "MMSavingAcc [accBal=" + accBal + "]";
	}
	@Override
	public void deposite(float amount) {
		
	}

}
