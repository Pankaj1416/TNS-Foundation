package impassintment;

public abstract class SavingAcc extends BankAcc {
	private boolean issalaried;
	private static float MINBAL=500;
	public SavingAcc(int accNo, String accNm, float accBal, boolean issalaried) {
		super(accNo, accNm, accBal);
	}
	@Override
	public void withdraw(float amount) {
	}
    	   
    	   
	@Override
	public String toString() {
		return "SavingAcc [issalaried=" + issalaried + "]";
	}
	
	
	

}
