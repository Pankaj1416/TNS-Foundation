package impassintment;

public class MMCurrentAcc extends CurrentAcc {
	 public MMCurrentAcc(int accNo, String accNm, float accBal, float creditLimit) {
		 super(accNo,accNm,accBal,creditLimit);
	 }

	@Override
	public void deposite(float amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {
		return "MMCurrentAcc [accBal=" + accBal + "]";
	}

}
